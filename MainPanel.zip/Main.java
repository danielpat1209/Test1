import utils.Utils;

import java.net.URI;

public class Main {

    //Google drive link: https://docs.google.com/document/d/16XKREqqzlJNLWHq5jZIminFVNuhuBTZHqwBKAsZnDFw/edit?usp=sharing

    public static void main(String[] args) {
       // Utils.saveIdentifyCode();
        if (true) {
            System.out.println(Utils.getCreds());
            Window window = new Window();
        }

    }
}
